create view viewexam as
select `demo`.`exam`.`name` AS `ViewExam1`, `demo`.`exam`.`address` AS `ViewExam2`
from `demo`.`exam`;

